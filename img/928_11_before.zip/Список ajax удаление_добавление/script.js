$( document ).ready(function (){
    $("#box").on('keydown', function(event){
        if (event.which == 13) {
            data = $('#box').val();//�������� ������ �� input
            let val = $(".list").append("<li>" + data);
            let child = $('.item').length;
            //let child = Number.parseInt($(".list").children.length) + 1;
            $("li:eq("+ child +")").addClass("item");
            $('#box').val("");
            
        };
    });

    $('.list').on('click', '.item', function() {
          $(this).remove();
    });
}); 